package com.example.appcellephack

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import com.example.appcellephack.databinding.ActivityCadastroBinding


class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Criando uma lista de opções para o spinner

        val listaContinentes = arrayListOf("Continente","'Africa","Antártida","América","Asia","Europa","Oceania")

        //Criando um adaptador para o Spinner
        val spinnerAdapter = ArrayAdapter(
            this,                                           //Contexto
            android.R.layout.simple_spinner_dropdown_item,  //Layout
            listaContinentes                                //Dados
        )

        //plugando o adaptador no spinner
        binding.spnCadastroContinente.adapter = spinnerAdapter

        //quando o botão cadastrar seja clicado
        binding.btnCadastroCadastrar.setOnClickListener {

            //Os dados digitados sõ capturdos em variáveis
            val nome        = binding.edtCadastroNome.text.toString().trim()
            val sobrenome   = binding.edtCadastroSobrenome.text.toString().trim()
            val email       = binding.edtCadastroEmail.text.toString().trim().lowercase()
            val senha       = binding.edtCadastroSenha.text.toString().trim()
            val continente  = binding.spnCadastroContinente.selectedItem.toString()

            //Aqui os campos do formulário são validados

            if (nome.isEmpty()      ||
                sobrenome.isEmpty() ||
                email.isEmpty()     ||
                senha.isEmpty()     ||
                continente == listaContinentes[0]) {

                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_LONG).show()

            }else{
                //se todos os campos foram preenchidos
                //criamso uma referência a um arquivo de preferências compartilhadas
                val sharedPrefs = getSharedPreferences(
                    "cadastro_$email",
                    Context.MODE_PRIVATE
                )
                //Aqui tornamosa shared prefreneces editável
                val editPrefs = sharedPrefs.edit()

                //aqui os dados sào salvos para serem salvos no arquivo

                editPrefs.putString("NOME", nome)
                editPrefs.putString("SOBRENOME", sobrenome)
                editPrefs.putString("EMAIL", email)
                editPrefs.putString("SENHA", senha)
                editPrefs.putString("CONTINENTE", continente)

                editPrefs.apply()

                val mIntent = Intent(this, MainActivity::class.java)

                //aqui é mostrado como passar dados entre activities
                // o email será utilizado pela MainActivity para acessar o SharedPreferences
                mIntent.putExtra("INTENT_EMAIL", email)
                startActivity(mIntent)
                // este método remove todas as activities da pilha
                finishAffinity()
            }
        }
    }
}