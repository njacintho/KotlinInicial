package com.example.appcellephack

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.appcellephack.databinding.ActivityLoginctivityBinding

class LoginActivity : AppCompatActivity() {
    //técnica utilizada para inicializar  uma variavel sem que seja nula
    private lateinit var binding: ActivityLoginctivityBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginctivityBinding.inflate(layoutInflater)//método em inflate
        setContentView(binding.root) //encaminha através do binfing

        //Quando o botão entrar for clicado ele faça...
        binding.btnLoginEntrar.setOnClickListener {

            val email = binding.edtLoginEmail.text.toString().trim().lowercase()
            val senha = binding.edtLoginSenha.text.toString().trim()

            if (email.isEmpty()){
                binding.edtLoginEmail.error = "Campo obrigatório"
                binding.edtLoginEmail.requestFocus()
            }else if (senha.isEmpty()){
                binding.edtLoginSenha.error = "Campo obrigatório"
                binding.edtLoginSenha.requestFocus()
            }else{
                //Acesssando o arquivo do Shared Preferences
                val sharedPrefs = getSharedPreferences(
                    "cadastro_$email",
                    Context.MODE_PRIVATE
                )
                // Recupereando dados no arquivo de shared preferences
                val emailPrefs = sharedPrefs.getString("EMAIL", "")
                val senhaPrefs = sharedPrefs.getString("SENHA", "")
                //Aqui será validado se o email e senha batem
                if(email == emailPrefs && senha == senhaPrefs){

                    Toast.makeText(this,"Usuário logado", Toast.LENGTH_LONG).show()

                    val mIntent = Intent(this,MainActivity::class.java)
                    //passando o email via Intent para a Main Activity
                    mIntent.putExtra("INTENT_EMAIL", email)

                    startActivity(mIntent)

                    finish()
                }else{
                    Toast.makeText(this, "Email ou senha inválidos", Toast.LENGTH_LONG).show()
                }
            }

        }
        binding.btnLoginCadastrar.setOnClickListener {
            val mIntent = Intent(this, CadastroActivity::class.java)
            startActivity(mIntent)
        }
    }
}