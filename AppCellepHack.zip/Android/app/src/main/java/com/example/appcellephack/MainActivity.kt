package com.example.appcellephack

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import com.example.appcellephack.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //recuperar o email passado por meio do Intent
        val email = intent.getStringExtra("INTENT_EMAIL")

        //Acessar o arquivo Shared Preferences
        val sharedPrefs = getSharedPreferences(
            "cadastro_$email",          //Nome do arquivo
            Context.MODE_PRIVATE        //Modo de acesso
        )

        val nome        = sharedPrefs.getString("NOME", "")
        val sobrenome   = sharedPrefs.getString("SOBRENOME", "")
        val continente  = sharedPrefs.getString("CONTINENTE", "")

        binding.txvMainNome.text = "$nome $sobrenome"
        binding.txvMainEmail.text = email
        binding.txvMainContinente.text = continente

        binding.btnMainSair.setOnClickListener {

            //Criar uma caixa de dialogo
            val alert = AlertDialog.Builder(this)
            //Definindo o título da caixa de diálogo
            alert.setTitle("Atenção!")
            // definimos o Corpo da mensagem
            alert.setMessage("Deseja mesmo Sair?")
            //Definindo o rótulo do botão e escutando o seu clique
            alert.setPositiveButton("Sair"){ dialog, which ->
                val mIntent = Intent(this, LoginActivity::class.java)
                startActivity(mIntent)
                //Eliminando a tela da pilha
                finishAffinity()
            }
            //botão Não
            alert.setNeutralButton("Não"){dialog,which ->}
            //botão Sair
            alert.setCancelable(false)
            // desabilita a possibilidade do usuário cancelar clicando fora da caixa
            alert.show()
        }

        binding.btnMainSite.setOnClickListener {
            // escutando o clique do botão Site Cellep
            val mIntent = Intent(this, WebActivity::class.java)
            startActivity(mIntent)
        }
    }
}